create function fnc_trg_person_audit() returns trigger
    language plpgsql
as
$$
    BEGIN
        IF (TG_OP = 'INSERT') THEN
            INSERT INTO person_audit
                SELECT
                         now(),
                         'I',
                         new.id, new.name, new.age, new.gender, new.address;
        ELSIF (TG_OP = 'UPDATE') THEN
            INSERT INTO person_audit(created, type_event, row_id, name, age, gender, address)
            VALUES(
                now(),
                'U',
                OLD.id, OLD.name, OLD.age, OLD.gender, OLD.address);
        ELSIF (TG_OP = 'DELETE') THEN
            INSERT INTO person_audit(created, type_event, row_id, name, age, gender, address)
            VALUES(
                now(),
                'D',
                OLD.id, OLD.name, OLD.age, OLD.gender, OLD.address);
        END IF;
        RETURN NULL;
    END;
$$;

alter function fnc_trg_person_audit() owner to "D_Daria";

