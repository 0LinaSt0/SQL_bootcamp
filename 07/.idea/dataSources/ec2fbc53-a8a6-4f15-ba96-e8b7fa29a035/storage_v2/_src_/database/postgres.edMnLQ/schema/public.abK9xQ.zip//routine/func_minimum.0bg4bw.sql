create function func_minimum(VARIADIC arr numeric[]) returns numeric
    language plpgsql
as
$$
    BEGIN
        RETURN (SELECT MIN(i) FROM unnest($1) i);
    END;
$$;

alter function func_minimum(numeric[]) owner to "D_Daria";

