create function fnc_persons(pgender character varying DEFAULT 'female'::character varying)
    returns TABLE(id bigint, name character varying, age integer, gender character varying, address character varying)
    language sql
as
$$
        (SELECT
                person.id, person.name, person.age, person.gender, person.address
        FROM person
            WHERE person.gender = pgender);
$$;

alter function fnc_persons(varchar) owner to "D_Daria";

