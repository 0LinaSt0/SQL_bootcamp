create function func_minimum(arr real[]) returns numeric
    language plpgsql
as
$$
    BEGIN
        RETURN (SELECT MIN(arr) FROM unnest(arr));
    END;
$$;

alter function func_minimum(real[]) owner to "D_Daria";

