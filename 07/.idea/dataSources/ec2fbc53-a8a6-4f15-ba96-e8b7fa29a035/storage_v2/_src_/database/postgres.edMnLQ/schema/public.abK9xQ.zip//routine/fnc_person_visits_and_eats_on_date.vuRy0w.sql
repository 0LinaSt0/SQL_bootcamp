create function fnc_person_visits_and_eats_on_date(pperson character varying DEFAULT 'Dmitriy'::character varying, pprice numeric DEFAULT 500, pdate date DEFAULT '2022-01-08'::date)
    returns TABLE(name character varying)
    language plpgsql
as
$$
    BEGIN
        RETURN QUERY
            SELECT
                pizzeria.name
                FROM person_visits
                INNER JOIN person ON person_visits.person_id = person.id
                JOIN menu ON person_visits.pizzeria_id = menu.pizzeria_id
                JOIN pizzeria ON menu.pizzeria_id= pizzeria.id
                WHERE person.name = pperson AND visit_date = pdate AND price < pprice;
    END;
$$;

alter function fnc_person_visits_and_eats_on_date(varchar, numeric, date) owner to "D_Daria";

