create function fnc_fibonacci(pstop integer DEFAULT 10)
    returns TABLE(num integer)
    language sql
as
$$
    WITH RECURSIVE cte_fib(num1, num2) AS (
        VALUES (0, 1)
        UNION ALL
            SELECT
            GREATEST(num1, num2), num1 + num2
        FROM cte_fib
            WHERE num2 < pstop
    )
    SELECT num1 FROM cte_fib;
$$;

alter function fnc_fibonacci(integer) owner to "D_Daria";

