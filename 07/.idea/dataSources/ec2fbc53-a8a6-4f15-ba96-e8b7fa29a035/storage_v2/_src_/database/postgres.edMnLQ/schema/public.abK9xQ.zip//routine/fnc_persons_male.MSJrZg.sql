create function fnc_persons_male()
    returns TABLE(id bigint, name character varying, age integer, gender character varying, address character varying)
    language sql
as
$$
        (SELECT
                person.id, person.name, person.age, person.gender, person.address
        FROM person
            WHERE person.gender = 'male');
$$;

alter function fnc_persons_male() owner to "D_Daria";

