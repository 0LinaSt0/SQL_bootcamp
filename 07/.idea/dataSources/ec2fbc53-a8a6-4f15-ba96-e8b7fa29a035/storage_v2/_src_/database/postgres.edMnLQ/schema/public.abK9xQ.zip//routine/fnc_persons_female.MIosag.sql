create function fnc_persons_female()
    returns TABLE(id bigint, name character varying, age integer, gender character varying, address character varying)
    language sql
as
$$
        (SELECT
                person.id, person.name, person.age, person.gender, person.address
        FROM person
            WHERE person.gender = 'female');
$$;

alter function fnc_persons_female() owner to "D_Daria";

