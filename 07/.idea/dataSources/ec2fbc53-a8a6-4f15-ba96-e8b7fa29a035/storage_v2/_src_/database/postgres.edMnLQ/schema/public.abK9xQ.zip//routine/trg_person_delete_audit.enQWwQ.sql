create function trg_person_delete_audit() returns trigger
    language plpgsql
as
$$
    BEGIN
        IF (TG_OP = 'DELETE') THEN
            INSERT INTO person_audit(created, type_event, row_id, name, age, gender, address)
                    VALUES(
                         now(),
                         'D',
                         OLD.id, OLD.name, OLD.age, OLD.gender, OLD.address);
        END IF;
        RETURN NULL;
    END;
$$;

alter function trg_person_delete_audit() owner to "D_Daria";

